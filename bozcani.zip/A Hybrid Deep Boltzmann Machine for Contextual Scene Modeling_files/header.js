document.write('\
<div>\
<a href="http://www.kovan.ceng.metu.edu.tr/" target="_self"><img src="./A Hybrid Deep Boltzmann Machine for Contextual Scene Modeling_files/kovan_logo_yan.png" style="margin-top: 5px;" height="80px" width="289px" /></a>\
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\
<div class="icon"><a href="http://www.kovan.ceng.metu.edu.tr/"><img src="./A Hybrid Deep Boltzmann Machine for Contextual Scene Modeling_files/home.svg">Home</a></div>\
<div class="icon"><a href="http://www.kovan.ceng.metu.edu.tr/index.php/Research"><img src="./A Hybrid Deep Boltzmann Machine for Contextual Scene Modeling_files/research.svg">Research</a></div>\
<div class="icon"><a href="http://www.kovan.ceng.metu.edu.tr/index.php/Publications"><img src="./A Hybrid Deep Boltzmann Machine for Contextual Scene Modeling_files/publications.svg">Publications</a></div>\
<div class="icon"><a href="http://www.kovan.ceng.metu.edu.tr/index.php/Members"><img src="./A Hybrid Deep Boltzmann Machine for Contextual Scene Modeling_files/people.svg">People</a></div>\
</div>\
');

//<div style="height: 90px; width: 299px; display: inline;"></div>
//<div style="float: right; margin-top: 20px;">\
