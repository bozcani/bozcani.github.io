document.write('\
<div style="text-align: center; width: 100%; margin-top: 25px; ">\
<p style="color: #999; font-size: 9pt; ">\
&copy; <script>document.write(new Date().getFullYear())</script> KOVAN Research Lab \
&#8210; <a href="http://www.ceng.metu.edu.tr/" style="color:#EE7F2D;">Department of Computer Engineering</a> @ <a href="http://www.metu.edu.tr/"  style="color:#EE7F2D;">Middle East Technical University</a> &#8210; Üniversiteler Mahallesi, Dumlupınar Bulvarı No:1,06800 Çankaya Ankara/TÜRKİYE.\
</p></div>\
');
